USE [NBank]
GO

/****** Object:  UserDefinedTableType [dbo].[CompanyIdList]    Script Date: 20-01-2026 01:51:33 PM ******/
CREATE TYPE [dbo].[CompanyIdList] AS TABLE(
	[CompanyId] [bigint] NULL
)
GO


