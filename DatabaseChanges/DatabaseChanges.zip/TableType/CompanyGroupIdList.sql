CREATE TYPE dbo.CompanyGroupIdList AS TABLE
(
    CompanyGroupId BIGINT
);
GO